/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package aplicacion8.pkg12;

/**
 *
 * @author David
 */
public enum Unidad {
       CM, M
}
